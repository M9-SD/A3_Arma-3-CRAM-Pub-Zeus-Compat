protocol = 1;
publishedid = 2825319340;
name = "Vanilla CRAM";
timestamp = 5249652844263402674;
