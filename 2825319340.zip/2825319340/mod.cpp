name = "Vanilla CRAM";
tooltipOwned = "Tool Tip";
overview = "This mod adds allows the vanilla CRAM to intercept incoming ammo.";

picture = "CRAM.paa"; 
logo = "LOGO.paa";

action = "";

hideName = 0;
hidePicture = 0;