class BIS_AddonInfo
{
	author="Dankan37";
	timepacked="1681389829";
};
