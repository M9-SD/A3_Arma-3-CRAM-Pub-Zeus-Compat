#include "BIS_AddonInfo.hpp"
class cfgPatches 
{
    class D37_cram
    {
        units[] = {"CRAM_Fake_PlaneTGT", "CRAM_AAA_System_01_base_F","ModuleCRAM_initCram"};
		weapons[] = {};
		requiredVersion = 0.1;
		requiredAddons[] = {"A3_Static_F_Jets_AAA_System_01", "A3_Modules_F"};
    };
};

class cfgFunctions {
	class CRAM37 {
		tag = "CRAM37";
		file = "D37_cram\functions";
		class scripts {
			class handleCRAM {};
			class pickTarget {};
			class postInit {postInit = 1;};
			class handleCRAMinit {};
			class handleCuratorPlacement {};
		};
	};
};

class CfgSounds
{
	class CRAMALARM
	{
		name = "CRAM_Alarm";
		sound[] = {"D37_cram\Sound\CRAM_ALARM.ogg", 1.0, 1.0};
		titles[] = {0, ""};
	};
};

class cfgVehicles {
    //B_AAA_System_01_F
	//["AAA_System_01_base_F","StaticMGWeapon","StaticWeapon","LandVehicle","Land","AllVehicles","All"]
	
	class AllVehicles;
	class Land: AllVehicles {};
	class LandVehicle: Land {};
	class StaticWeapon: LandVehicle {};
	class StaticMGWeapon: StaticWeapon {};
	class AAA_System_01_base_F: StaticMGWeapon{
		class EventHandlers;

		class Turrets {
			class MainTurret;
		};
	};
	class B_AAA_System_01_F:AAA_System_01_base_F {
		class Turrets: Turrets {
			class MainTurret: MainTurret {
				magazines[] = {"magazine_Cannon_Phalanx_x1550","magazine_Cannon_Phalanx_x1550","magazine_Cannon_Phalanx_x1550"};
			};
		};
	};
	class CRAM_AAA_System_01_base_F:B_AAA_System_01_F {
		displayName = "CRAM";
		class EventHandlers: EventHandlers {
			class CRAM37 {
				init = "[_this select 0] remoteExec ['CRAM37_fnc_handleCRAM', 0];";
				//init = "[_this select 0] spawn CRAM37_fnc_handleCRAM; systemchat str (local (_this # 0));";
			};
		};
	};

	//["Plane_Fighter_01_Base_F","Plane_Base_F","Plane","Air","AllVehicles","All"]
	class Air: AllVehicles {};
	class Plane: Air {};
	class Plane_Base_F: Plane {};
	class Plane_Fighter_01_Base_F: Plane_Base_F {};
	class B_Plane_Fighter_01_F: Plane_Fighter_01_Base_F {
		class EventHandlers {};
	};

	class CRAM_Fake_PlaneTGT: B_Plane_Fighter_01_F {
		model = "\A3\Weapons_f\Data\bullettracer\tracer_red";
		displayName = "Radar Target (SHELL)";
		cost = 1e+015;
		radarTarget = 1;
		radarTargetSize = 1;
		scope = 1;
	};

	class Logic;
	class Module_F: Logic
	{
		class AttributesBase
		{
			class Default;
			class Edit;
			class Combo;
			class Checkbox;
			class CheckboxNumber;
			class ModuleDescription;
			class Units;
		};
		class ModuleDescription
		{
			class AnyBrain;
		};
	};
	
	class ModuleCRAM_initCram: Module_F
	{
		displayName = "Init CRAM";
		author = "Dankan37";
		scope = 2;
		scopeCurator = 2;
		category = "CRAM_modules";
		
		isGlobal = 1;
		function = "CRAM37_fnc_handleCRAMinit";
		class Attributes: AttributesBase
		{
			class Units: Units
			{
				property = "ModuleCBRN_RemoveExposure_Units";
			};	
		};
	};
};

class CfgFactionClasses
{
	class CRAM_modules
	{
		displayName = "CRAM modules";
		priority = 10;
	};
};